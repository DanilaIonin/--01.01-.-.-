﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDoctors.xaml
    /// </summary>
    public partial class PageDoctors : Page
    {
        public PageDoctors()
        {
            InitializeComponent();
            DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.ToList();
        }

        private void MenuAddDoctor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddDoctors(null));
        }

        private void MenuEditDoctor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddDoctors((Doctors)DtgSQLD.SelectedItem));
        }

        private void MenuDelDoctor_Click(object sender, RoutedEventArgs e)
        {
            var doctorsForRemoving = DtgSQLD.SelectedItems.Cast<Doctors>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {doctorsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    PolyclinicEntities1.GetContext().Doctors.RemoveRange(doctorsForRemoving);
                    PolyclinicEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionVisits_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVisits());
        }

        private void BtnTransitionPatient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PagePatients());
        }

        private void txbSearchDocSur_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLD.ItemsSource != null)
            {
                DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.Where(x => x.SurnameD.ToLower().Contains(txbSearchDocSur.Text.ToLower())).ToList();
            }
            if (txbSearchDocSur.Text.Count() == 0) DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.ToList();
        }

        private void txbSearchDocSpec_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLD.ItemsSource != null)
            {
                DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.Where(x => x.SpecializationD.ToLower().Contains(txbSearchDocSpec.Text.ToLower())).ToList();
            }
            if (txbSearchDocSpec.Text.Count() == 0) DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.ToList();
        }

        private void MenuSortSurnameD1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.OrderBy(x => x.SurnameD).ToList();
        }

        private void MenuSortSurnameD2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.OrderByDescending(x => x.SurnameD).ToList();
        }

        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.ToList();
        }

        private void MenuFilterCab1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.Where(x => x.CabinetNumber >= 10 && x.CabinetNumber <= 15).ToList();
        }

        private void MenuFilterCab2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.Where(x => x.CabinetNumber >= 16 && x.CabinetNumber < 20).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLD.ItemsSource = PolyclinicEntities1.GetContext().Doctors.ToList();
        }
    }
}
