﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PagePatients.xaml
    /// </summary>
    public partial class PagePatients : Page
    {
        public PagePatients()
        {
            InitializeComponent();
            DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }

        private void MenuAddPatient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddPatients(null));
        }

        private void MenuEditPatient_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddPatients((Patients)DtgSQLP.SelectedItem));
        }

        private void MenuDelPatient_Click(object sender, RoutedEventArgs e)
        {
            var patientsForRemoving = DtgSQLP.SelectedItems.Cast<Patients>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {patientsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    PolyclinicEntities1.GetContext().Patients.RemoveRange(patientsForRemoving);
                    PolyclinicEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionVisit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVisits());
        }

        private void BtnTransitionDoctor_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDoctors());
        }

        private void txbSearchPatSur_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLP.ItemsSource != null)
            {
                DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.Where(x => x.SurnameP.ToLower().Contains(txbSearchPatSur.Text.ToLower())).ToList();
            }
            if (txbSearchPatSur.Text.Count() == 0) DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }

        private void txbSearchPatName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLP.ItemsSource != null)
            {
                DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.Where(x => x.NameP.ToLower().Contains(txbSearchPatName.Text.ToLower())).ToList();
            }
            if (txbSearchPatName.Text.Count() == 0) DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }

        private void MenuSortSurnameP1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.OrderBy(x => x.SurnameP).ToList();
        }

        private void MenuSortSurnameP2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.OrderByDescending(x => x.SurnameP).ToList();
        }

        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }

        private void MenuFilterDBP1_Click(object sender, RoutedEventArgs e)
        {
            DateTime date1 = new DateTime(2000, 1, 1);
            DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.Where(x => x.DateOfBirthP < date1).ToList();
        }

        private void MenuFilterDBP2_Click(object sender, RoutedEventArgs e)
        {
            DateTime date2 = new DateTime(2000, 1, 1);
            DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.Where(x => x.DateOfBirthP > date2).ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLP.ItemsSource = PolyclinicEntities1.GetContext().Patients.ToList();
        }
    }
}
