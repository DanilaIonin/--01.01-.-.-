﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Polyclinic.Classes;

namespace Polyclinic.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageVisits.xaml
    /// </summary>
    public partial class PageVisits : Page
    {
        public PageVisits()
        {
            InitializeComponent();
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void MenuAddVisit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddVisits(null));
        }

        private void MenuEditVisit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddVisits((Visits)DtgSQLV.SelectedItem));
        }

        private void MenuDelVisit_Click(object sender, RoutedEventArgs e)
        {
            var visitsForRemoving = DtgSQLV.SelectedItems.Cast<Visits>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {visitsForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    PolyclinicEntities1.GetContext().Visits.RemoveRange(visitsForRemoving);
                    PolyclinicEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnTransitionDoctors_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDoctors());
        }

        private void BtnTransitionPatients_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PagePatients());
        }

        private void MenuSortDiagnosis1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.OrderBy(x => x.DiagnosisP).ToList();
        }

        private void MenuSortDiagnosis2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.OrderByDescending(x => x.DiagnosisP).ToList();
        }
        private void MenuSortСlear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void MenuFilterVisit1_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.Where(x => x.CurrentStatusP == "Больной").ToList();
        }

        private void MenuFilterVisit2_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.Where(x => x.CurrentStatusP == "Здоров").ToList();
        }

        private void MenuFilterClear_Click(object sender, RoutedEventArgs e)
        {
            DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void txbSearchP_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLV.ItemsSource != null)
            {
                DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.Where(x => x.Patients.SurnameP.ToLower().Contains(txbSearchP.Text.ToLower())).ToList();
            }
            if (txbSearchP.Text.Count() == 0) DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }

        private void txbSearchD_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgSQLV.ItemsSource != null)
            {
                DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.Where(x => x.Doctors.SurnameD.ToLower().Contains(txbSearchD.Text.ToLower())).ToList();
            }
            if (txbSearchD.Text.Count() == 0) DtgSQLV.ItemsSource = PolyclinicEntities1.GetContext().Visits.ToList();
        }
    }
}
